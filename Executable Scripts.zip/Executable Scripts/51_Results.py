#!/usr/bin/env python
# coding: utf-8

# In[1]:


import matplotlib.pyplot as plt
import numpy as np


# In[13]:


# Model names
models = [
    "SimpleCNN",
    "EfficientNetB0",
    "EfficientNetB1",
    "DenseNet121",
    "SimpleCNN",
    "AlexNet",
    "VGG16",
    "ResNet18",
    "MobileNetV2"
]

# Metrics for each model
accuracies = [0.9730, 0.9730, 0.8311, 0.9865, 0.9865, 0.6757, 0.9865, 0.9865, 0.9932]
precisions = [0.9749, 0.9749, 0.8534, 0.9870, 0.9870, 0.5323, 0.9870, 0.9870, 0.9934]
recalls = [0.9730, 0.9730, 0.8311, 0.9865, 0.9865, 0.6757, 0.9865, 0.9865, 0.9932]
f1_scores = [0.9729, 0.9729, 0.8266, 0.9865, 0.9865, 0.5766, 0.9865, 0.9865, 0.9932]

# Convert to numpy arrays for easier handling
accuracies = np.array(accuracies)
precisions = np.array(precisions)
recalls = np.array(recalls)
f1_scores = np.array(f1_scores)

# Plotting the metrics
x = np.arange(len(models))  # the label locations
width = 0.2  # the width of the bars

fig, ax = plt.subplots(figsize=(12,  10))

# Define bar colors
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']

# Plot bars
rects1 = ax.bar(x - 1.5*width, accuracies, width, label='Accuracy', color=colors[0])
rects2 = ax.bar(x - 0.5*width, precisions, width, label='Precision', color=colors[1])
rects3 = ax.bar(x + 0.5*width, recalls, width, label='Recall', color=colors[2])
rects4 = ax.bar(x + 1.5*width, f1_scores, width, label='F1 Score', color=colors[3])

# Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_ylabel('Scores')
ax.set_title('Model Performance Metrics')
ax.set_xticks(x)
ax.set_xticklabels(models, rotation=45, ha='right')
ax.legend()

# Function to add labels on bars
def add_labels(rects):
    for rect in rects:
        height = rect.get_height()
        ax.annotate(f'{height:.4f}',
                    xy=(rect.get_x() + rect.get_width() / 2, height),
                    xytext=(0, 3),  # 3 points vertical offset
                    textcoords="offset points",
                    ha='center', va='bottom')

# Add labels to each bar
add_labels(rects1)


fig.tight_layout()

plt.show()
fig.savefig('Model Performance Metrics.png')

